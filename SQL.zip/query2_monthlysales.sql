WITH MonthlySales AS (
    SELECT 
        product_id AS sku,
        EXTRACT(YEAR FROM order_date) AS sales_year,
        EXTRACT(MONTH FROM order_date) AS sales_month,
        SUM(order_quantity) AS volume_sold
    FROM orders
    GROUP BY product_id, EXTRACT(YEAR FROM order_date), EXTRACT(MONTH FROM order_date)
)
SELECT 
    sku,
    sales_year,
    sales_month,
    volume_sold,
    ROUND(
        AVG(volume_sold) OVER (
            PARTITION BY sku 
            ORDER BY sales_year, sales_month 
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 1
    ) AS rolling_3_month_avg
FROM MonthlySales
ORDER BY sku, sales_year, sales_month;