CREATE TABLE inventory (
    Inventory_Record_ID INT AUTO_INCREMENT PRIMARY KEY,
    SKU_ID TEXT,
    Product_Name TEXT,
    Category TEXT,
    Sub_Category TEXT,
    Month TEXT,
    Opening_Stock INT,
    Units_Sold INT,
    Units_Received INT,
    Closing_Stock INT,
    Reorder_Point INT,
    Max_Stock_Level INT,
    Stockout_Flag TEXT,
    Unit_Cost_USD DOUBLE,
    Moving_Average INT,
    Exponential_Smoothing DOUBLE
);

