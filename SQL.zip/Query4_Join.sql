SELECT
    s.Supplier_Name,
    COUNT(o.Order_ID) AS Total_Orders,
    ROUND(AVG(o.Delivery_Delay_Days),2) AS Avg_Delay
FROM Orders o
INNER JOIN Suppliers s
    ON o.Supplier_ID = s.Supplier_ID
GROUP BY s.Supplier_Name
ORDER BY Avg_Delay DESC;