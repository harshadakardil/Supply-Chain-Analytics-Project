CREATE TABLE suppliers (
    Supplier_ID VARCHAR(50) PRIMARY KEY,
    Supplier_Name TEXT,
    Supplier_Country TEXT,
    Lead_Time_Days DOUBLE,
    Fill_Rate_Pct DOUBLE,
    Defect_Rate_Pct DOUBLE,
    Cost_Per_Unit_USD DOUBLE,
    On_Time_Supply_Pct DOUBLE,
    Annual_Contract_Value_USD DOUBLE,
    Preferred_Carrier TEXT,
    Category_Supplied TEXT
);