CREATE TABLE orders (
    Order_ID VARCHAR(50) PRIMARY KEY,
    Order_Date TEXT,
    Customer_ID TEXT,
    Product_ID TEXT,
    Product_Category TEXT,
    Product_Sub_Category TEXT,
    Order_Quantity INT,
    Unit_Price_USD DOUBLE,
    Order_Value_USD DOUBLE,
    Supplier_ID TEXT,
    Region TEXT,
    State TEXT,
    Warehouse TEXT,
    Carrier TEXT,
    Shipping_Mode TEXT,
    Shipment_Distance_KM INT,
    Shipment_Weight_KG DOUBLE,
    Shipping_Cost_USD DOUBLE,
    Cost_Per_Unit_Shipped DOUBLE,
    Promised_Delivery_Date TEXT,
    Actual_Delivery_Date TEXT,
    Delivery_Delay_Days INT,
    On_Time_Delivery TEXT,
    Lead_Time INT,
    Defective_Order TEXT,
    Return_Flag TEXT,
    Customer_Segment TEXT,
    
	CONSTRAINT fk_supplier
    FOREIGN KEY (Supplier_ID)
    REFERENCES suppliers(Supplier_ID)
);