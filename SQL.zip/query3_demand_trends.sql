WITH RegionalCarrierPerformance AS (
    SELECT 
        region,
        carrier,
        COUNT(order_id) AS shipment_volume,
        ROUND(AVG(delivery_delay_days), 2) AS average_transit_delay,
        DENSE_RANK() OVER (
            PARTITION BY region 
            ORDER BY AVG(delivery_delay_days) DESC
        ) AS performance_rank
    FROM orders
    GROUP BY region, carrier
)
SELECT 
    region,
    carrier,
    shipment_volume,
    average_transit_delay,
    performance_rank
FROM RegionalCarrierPerformance
WHERE performance_rank <= 2
ORDER BY region, performance_rank;