SELECT 
    carrier,
    COUNT(order_id) AS total_shipments,
    ROUND(AVG(delivery_delay_days), 2) AS avg_delay_days,
    ROUND(STDDEV_SAMP(delivery_delay_days), 2) AS delay_standard_deviation,
    ROUND(SUM(CASE WHEN delivery_delay_days <= 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(order_id), 1) AS on_time_delivery_rate_pct,
    ROUND(SUM(shipping_cost_usd) / SUM(order_quantity), 2) AS unit_shipping_cost_usd
FROM orders
GROUP BY carrier
ORDER BY avg_delay_days ASC;